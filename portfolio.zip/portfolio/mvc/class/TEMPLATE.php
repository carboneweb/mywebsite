<?php

// classe:          TEMPLATE
// date creation:   DATE 
// version:         1.0 
// auteur:          AUTEUR

class TEMPLATE
{
    // DEBUT DU CODE DE LA CLASSE
    
    // PROPRIETES
    // AJOUTER VOS PROPRIETES ICI
    // public $nom;
    
    // METHODES
    // CONSTRUCTEUR
    function __construct ()
    {
        
    }
    
    // AJOUTER VOS METHODES ICI
    // ...
    
    // FIN DU CODE DE LA CLASSE
}

// NE RIEN ECRIRE ICI

// LA FIN DU FICHIER SERT DE BALISE FERMANTE POUR PHP

<?php

// classe:          Model
// date creation:   2016-08-29 08:32:33 
// version:         1.0 
// auteur:          MOI MEME

class Model
{

    function __construct ()
    {
        
    }
    
    function connexionBDD ()
    {
        // CONNEXION A LA BDD SQL
        $userSQL        = "**";
        $passwordSQL    = "****";
        $hostSQL        = "***";
        $databaseSQL    = "***";       // A CREER DANS PHPMYADMIN
        
        $dsn            = "mysql:host=$hostSQL;dbname=$databaseSQL;charset=utf8";
        
        // CREER LA REQUETE SQL
        $objetPDO       = new PDO($dsn, $userSQL, $passwordSQL);
        
        return $objetPDO;
    }
    
    
    function lancerRequeteSQL ($requeteSQL, $tableauToken)
    {
        $objetPDO = $this->connexionBDD();

        // PREPARE
        // PROTECTION CONTRE LES INJECTIONS SQL 
        
        $objetPDOStatement = $objetPDO->prepare($requeteSQL);
        
        // EXECUTE
        $objetPDOStatement->execute($tableauToken);
        
    }
    
    
    
    // AJOUTE UNE NOUVELLE LIGNE DANS LA TABLE Contact
    function enregistrerContact($nom, $prenom, $email, $objet, $message)
    {

        // PREPARE
        $requeteSQL     =
<<<CODESQL
INSERT INTO  `contact` 
(`id` , `nom` , `prenom`, `email`, `objet`, `message`)
VALUES 
(NULL ,  :nom,  :prenom,  :email,  :objet,  :message);
CODESQL;

        // PROTECTION CONTRE LES INJECTIONS SQL 
        $tableauToken   = [
            ":nom"      => $nom,
            ":prenom"   => $prenom,
            ":objet"    => $objet,
            ":email"    => $email,
            ":message"  => $message,
            ];
        
        // $objetPDO DELEGUE A $objetPDOStatement L'EXECUTION DE LA REQUETE
        $this->lancerRequeteSQL($requeteSQL, $tableauToken);
        
    }
    
    // FIN DU CODE DE LA CLASSE
}



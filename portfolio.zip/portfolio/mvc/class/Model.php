<?php

// classe:          Model
// date creation:   2016-08-29 08:32:33 
// version:         1.0 
// auteur:          MOI MEME

class Model
{
    // DEBUT DU CODE DE LA CLASSE
    
    // PROPRIETES
    // AJOUTER VOS PROPRIETES ICI
    // public $nom;
    
    // METHODES
    // CONSTRUCTEUR
    function __construct ()
    {
        
    }
    
    function connexionBDD ()
    {
        // CONNEXION A LA BDD SQL
        $userSQL        = "dbo651943605";
        $passwordSQL    = "Jufoot.1987";
        $hostSQL        = "db651943605.db.1and1.com";
        $databaseSQL    = "db651943605";       // A CREER DANS PHPMYADMIN
        
        // ON PRECISE charset=utf8 POUR LA COMMUNICATION ENTRE PHP ET MYSQL
        $dsn            = "mysql:host=$hostSQL;dbname=$databaseSQL;charset=utf8";
        
        // CREER LA REQUETE SQL
        $objetPDO       = new PDO($dsn, $userSQL, $passwordSQL);
        
        return $objetPDO;
    }
    
    
    function lancerRequeteSQL ($requeteSQL, $tableauToken)
    {
        // $this EST LE MEME OBJET QUE CELUI DE enregistrerNewsletter
        $objetPDO = $this->connexionBDD();

        // PREPARE
        // PROTECTION CONTRE LES INJECTIONS SQL 
        // ON ANNONCE A MYSQL CE QU'ON VEUT FAIRE
        // $objetPDO DELEGUE A $objetPDOStatement L'EXECUTION DE LA REQUETE
        $objetPDOStatement = $objetPDO->prepare($requeteSQL);
        
        // EXECUTE
        $objetPDOStatement->execute($tableauToken);
        
    }
    
    
    
    // AJOUTE UNE NOUVELLE LIGNE DANS LA TABLE Contact
    function enregistrerContact($nom, $prenom, $email, $objet, $message)
    {

        // PREPARE
        $requeteSQL     =
<<<CODESQL
INSERT INTO  `contact` 
(`id` , `nom` , `prenom`, `email`, `objet`, `message`)
VALUES 
(NULL ,  :nom,  :prenom,  :email,  :objet,  :message);
CODESQL;

        // PROTECTION CONTRE LES INJECTIONS SQL 
        $tableauToken   = [
            ":nom"      => $nom,
            ":prenom"   => $prenom,
            ":objet"    => $objet,
            ":email"    => $email,
            ":message"  => $message,
            ];
        
        // $objetPDO DELEGUE A $objetPDOStatement L'EXECUTION DE LA REQUETE
        // ON ANNONCE A MYSQL CE QU'ON VEUT FAIRE
        $this->lancerRequeteSQL($requeteSQL, $tableauToken);
        
    }
    
    // FIN DU CODE DE LA CLASSE
}

// NE RIEN ECRIRE ICI

// LA FIN DU FICHIER SERT DE BALISE FERMANTE POUR PHP

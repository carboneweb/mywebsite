<?php

// VERIFICATION DU idForm
$idForm = lireInput("idForm");
if ($idForm == "contact")
{
    // RECUPERER LES INFOS DU FORMULAIRE & model mail
    $email             = lireInput("email");
    $nom               = lireInput("nom");
    $prenom            = lireInput("prenom");
    $objet             = lireInput("objet");
    $message           = lireInput("message");
    $headerMessage     = "MIME-Version: 1.0 \r\n"; 
    $headerMessage    .= "From: $email <$email> \r\n";
    $headerMessage    .= 'Content-Type: text/html; charset="UTF-8"'."\r\n";
    $headerMessage    .= 'Content-Transfer-Encoding: 8bit';
    $textMail          =
<<<descriptif
Bonjour Bruno, $email t'a envoyé : </br>
$objet </br>
$message </br>
descriptif;

    
    // SECURITE 
    if ( ($email != "") && ($message != "")  && (verifierEmail($email)) )
    {
        // OK
        // MESSAGE POUR LE VISITEUR
        setVar("contactMessageUser", "MERCI DE VOTRE MESSAGE $nom ($email)");
        
        // ENREGISTRER LES EMAILS DANS LA BASE DE DONNEES SQL
        $objetModel = new Model;
        $objetModel->enregistrerContact($nom, $prenom, $email, $objet, $message);
        
        //mail
        mail('bruno@carboneweb.com', "Message de $email sur carboneweb.com", "$textMail", "$headerMessage" );
}
    else
    {
        // KO
        setVar("contactMessageUser", "BIEN ESSAYE");
    }
}
<?php

//*******************************************************************
//  MODEL
//

// FONCTION QUI ME DONNE LA VALEUR D'UNE VARIABLE GLOBALE
// GETTER   => LECTURE => OBTENIR UNE INFORMATION
// ON POURRA UTILISER CETTE FONCTION DANS UNE AUTRE FONCTION
// POUR OBTENIR LA VALEUR D'UNE VARIABLE GLOBALE
// par exemple:
//      $varLocale = getVar("varGlobale");

function getVar ($nomVar)               // $nomVar EST UN PARAMETRE OBLIGATOIRE
{
    $ceQuiSortDeLaFonction = "";        // $ceQuiSortDeLaFonction EST UNE VARIABLE LOCALE ET JE LUI DONNE UNE VALEUR INITIALE
    if (isset($GLOBALS["$nomVar"]))     // VERIFIER SI LA VARIABLE EXISTE
    {
        $ceQuiSortDeLaFonction = $GLOBALS["$nomVar"];   // ALORS ON RECUPERE SA VALEUR
    }
    return $ceQuiSortDeLaFonction;
}

// SETTER => ECRITURE => MODIFIER LA VALEUR D'UNE VARIABLE GLOBALE
// ON POURRA UTILISER CETTE FONCTION DANS UNE AUTRE FONCTION
// POUR MODIFIER LA VALEUR D'UNE VARIABLE GLOBALE
// par exemple:
//      setVar("varGlobale", "Nouvelle Valeur");

function setVar ($nomVar, $nouvelleValeur)
{
    $GLOBALS["$nomVar"] = $nouvelleValeur;
}


//*******************************************************************
// VIEW
//

// AFFICHE LA VALEUR D'UNE VARIABLE DE MANIERE PLUS SECURISEE
// SI LA VARIABLE N'EXISTE PAS OU NE CONTIENT PAS DE VALEUR
// ALORS ON NE FAIT RIEN ET IL N'Y A PAS DE MESSAGE D'ERREUR PHP

function echoVar ($nomVar)              // $nomVar EST UN PARAMETRE OBLIGATOIRE
{
    $ceQuiSortDeLaFonction = "";        // $ceQuiSortDeLaFonction EST UNE VARIABLE LOCALE ET JE LUI DONNE UNE VALEUR INITIALE
    if (isset($GLOBALS["$nomVar"]))     // VERIFIER SI LA VARIABLE EXISTE
    {
        $ceQuiSortDeLaFonction = $GLOBALS["$nomVar"];   // ALORS ON RECUPERE SA VALEUR
    }
    echo $ceQuiSortDeLaFonction;
}


//*******************************************************************
//  CONTROLLER
// 

// LA FONCTION lireInput ME PERMET DE RECUPERER LES INFOS 
// ENVOYEES PAR LES FORMULAIRES DU NAVIGATEUR
// DE MANIERE PLUS SECURISEE
function lireInput ($attributNameDeLaBaliseInput)      // $attributNameDeLaBaliseInput EST UN PARAMETRE (COMME UNE VARIABLE)
{
    $resultat = "";
    
    // $_REQUEST CONTIENT LES INFOS GET ET POST
    // http://php.net/manual/en/function.isset.php
    // JE VAIS D'ABORD VERIFIER SI L'INFORMATION EST PRESENTE
    // SI OUI ALORS JE LA RECUPERE
    if (isset($_REQUEST["$attributNameDeLaBaliseInput"]))
    {
        // LES INFOS BRUTES (DANGEREUSES) SONT LA EN GET OU EN POST
        $resultat = $_REQUEST["$attributNameDeLaBaliseInput"];       
        
        // ENLEVER LES BALISE HTML, JS ET PHP
        // http://php.net/manual/en/function.strip-tags.php
        $resultat = strip_tags($resultat);
        
        // ENLEVER LES ESPACES AU DEBUT ET A LA FIN
        // http://php.net/manual/en/function.trim.php
        $resultat = trim($resultat);
    }
    return $resultat;
}

// LE BUT DE LA FONCTION verifierEmail EST DE VALIDER 
// SI $email EST UN EMAIL CORRECT OU NON
function verifierEmail ($paramEmail)     // $paramEmail EST UN PARAMETRE (VARIABLE LOCALE A LA FONCTION)
{
    // MODE PARANO => ON CONSIDERE QUE L'EMAIL EST INVALIDE AU DEPART    
    $resultat = false; 
    
    // http://php.net/manual/en/function.filter-var.php
    $emailFiltre = filter_var($paramEmail, FILTER_VALIDATE_EMAIL);
    if ( ($paramEmail != "")                     // $email DOIT ETRE DIFFERENT DU TEXTE VIDE 
            && ($emailFiltre == $paramEmail) )   // SI $email EST CORRECT ALORS $email et $emailFiltre SONT IDENTIQUES 
    {
        // OK
        $resultat = true;
    }
    
    return $resultat;
}

// VA VERIFIER SI UN VISITEUR A BIEN LE DROIT D'ACCES
function verifierLogin ()
{
    $resultat = false; // MODE PARANO
    
    // CODE POUR VERIFIER L'ACCES
    $idForm = lireInput("idForm");
    if ($idForm == "login")
    {
        // ON A LE FORMULAIRE DE LOGIN A TRAITER
        $email      = lireInput("email");
        $password   = lireInput("password");
        
        if ( verifierEmail($email)  && ($password != "") )
        {
            // IL FAUT VERIFIER SI ON TROUVE BIEN CES INFOS DANS NOTRE SITE
            // ON A UN FICHIER CSV mvc/model/login.csv
            // admin@gmail.com,abcd
            // user2@gmail.com,1234
            
            // LIRE TOUT LE CONTENU DU FICHIER
            // http://nl3.php.net/manual/fr/function.file-get-contents.php
            $contenuFichier = file_get_contents("mvc/model/login.csv");
            
            // POUR EXTRAIRE LES INFOS
            // JE DECOUPE EN LIGNES
            // JE DECOUPE CHAQUE LIGNE EN COLONNES
            // http://nl3.php.net/manual/fr/function.explode.php
            $tabLigne = explode("\n", $contenuFichier);
            
            // PARCOURIR CHAQUE LIGNE POUR EXTRAIRE LES COLONNES
            // BOUCLE COMME while EN PLUS SIMPLE
            // POUR CHAQUE CHAQUE LIGNE $ligne DU TABLEAU $tabLigne
            foreach($tabLigne as $ligne)
            {
                $tabColonne     = explode(",", $ligne);
                $emailCSV       = $tabColonne[0];
                $passwordCSV    = $tabColonne[1];
                
                // JE VERIFIE SI CA CORRESPOND AVEC LES INFOS DU FORMULAIRE
                if ( ($email == $emailCSV) && ($password == $passwordCSV) )
                {
                    // OK LA PERSONNE PEUT SE CONNECTER
                    $resultat = true;
                }
            }
        }
    }
    return $resultat;
}


//*******************************************************************
// PROGRAMMATION ORIENTE OBJET
//
// CHARGER AUTOMATIQUEMENT LA DECLARATION D'UNE CLASSE
// QUAND PHP EN A BESOIN
// QUAND PHP LIT DANS LE CODE
//      $objetPage = new Page;
//                          => $nomClasse = "Page"
function chargerClasse ($nomClasse)
{
    // DEBUG 
    //echo "<h1>va Chercher $nomClasse</h1>";
    
    // CHARGER AUTOMATIQUEMENT LA CLASSE
    // GRACE A LA CONVENTION
    // LA CLASSE Page EST DANS LE FICHIER mvc/class/Page.php
    $cheminFichierClasse = "mvc/class/$nomClasse.php";
    
    // VERIFIE SI LE FICHIER EXISTE ALORS JE LE CHARGE
    if (is_file($cheminFichierClasse))
    {   
        // LE FICHIER EXISTE
        // ON LE CHARGE
        require_once($cheminFichierClasse);
    }
    else 
    {
        // LE FICHIER N'EXISTE PAS
        // COMME ON EST DES FLEMMARDS
        // ON VA DIRE A PHP DE LE CREER POUR NOUS
        $cheminFichierTemplate = "mvc/class/TEMPLATE.php";
        // ON VERIFIE SI IL Y A UN FICHIER TEMPLATE.php
        // SINON ON NE FAIT RIEN
        if (is_file($cheminFichierTemplate))
        {
            // COPIER LE CONTENU DU FICHIER DANS UNE VARIABLE PHP
            // http://nl1.php.net/manual/fr/function.file-get-contents.php
            $contenuFichier = file_get_contents($cheminFichierTemplate);
            // JE REMPLACE TEMPLATE PAR $nomClasse
            
            //$contenuCode = str_replace("TEMPLATE", $nomClasse, $contenuFichier);
            
            $tabReplace = [
                "TEMPLATE" => $nomClasse,
                "DATE"     => date("Y-m-d H:i:s"),
                "AUTEUR"   => "MOI MEME",
                ];
            
            // JE REMPLACE LES TEXTES PAR D'AUTRES    
            // http://nl1.php.net/manual/fr/function.str-replace.php 
            $contenuCode = str_replace(array_keys($tabReplace), array_values($tabReplace), $contenuFichier);
            
            // JE SAUVEGARDE LE CONTENU DANS LE FICHIER (COMME UN Ctlr-S)
            // JE VAIS CREER LE FICHIER AVEC LE BON CODE DEDANS
            // http://nl1.php.net/manual/fr/function.file-put-contents.php
            file_put_contents($cheminFichierClasse, $contenuCode);
            
            // JE VAIS CHARGER LE CODE GENERE
            require_once($cheminFichierClasse);
            
        }
    }
        
}

// LA FIN DU FICHIER SERT DE BALISE FERMANTE POUR PHP
<div class="photo1" id="photo1"></div>
			<section id="realisations" class="realisations">
				<h3>Réalisations</h3>
				    <div class="ih-item square effect6 from_top_and_bottom"><a href="http://www.toutederosepoudree.com/">
				        <div class="img"><img src="media/img/toue-de-rose-poudree.png" alt="img"></div>
				        <div class="info">
				          <h3>Toute de rose poudrée</h3>
				          <p>Modification d'un thème existant sous Wordpress</p>
				        </div></a>
				    </div>
				    <div class="ih-item square effect6 from_top_and_bottom"><a href="http://movment.io/">
				        <div class="img"><img src="media/img/movment.png" alt="img"></div>
				        <div class="info">
				          <h3>Movment</h3>
				          <p>Mise en place d'un back-office pour les admins</p> 
				        </div></a>
				    </div>
			</section>
			
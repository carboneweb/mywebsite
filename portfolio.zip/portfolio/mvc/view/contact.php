<form class="contact" id="contact" method="POST" action="#contact">
				<h3>Contact</h3>
				<input type="text" name="nom" id="nom" placeholder="NOM"/>
				<input type="text" name="prenom" id="prenom" placeholder="PRENOM"/>
				<input type="email" name="email" id="email" placeholder="ADRESSE MAIL *" required/>
				<input type="text" name="objet" id="objet" placeholder="OBJET *" required/>
				<textarea name="message" id="message" placeholder="MESSAGE *" required></textarea>
				<input type="hidden" name="idForm" value="contact">
				<button>Envoyer</button>
				<p><?php echoVar("contactMessageUser")?></p>
			</form>
		</div>
	</main>
	<div class="clear" style="clear:both"></div>
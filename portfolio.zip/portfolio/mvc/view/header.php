<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<title>Bruno Carbone Dev Web</title>
		<meta name="viewport" content="width=320, height=device-height">		
		<meta name="Content-Type" content="UTF-8">
		<meta name="Content-Language" content="fr">
		<meta name="Subject" content="développeur web marseille">
		<script src="https://use.fontawesome.com/529670ced7.js"></script>
		<link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet"> 
		<link rel="stylesheet" type="text/css" href="media/reset.css"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
		<link rel="stylesheet" type="text/css" href="media/ihover.css"/>
		<link rel="stylesheet" type="text/css" href="media/style.css"/>
	</head>
	<body>
		<nav id="navDesk">
			<ul>
				<li><a href="#presentation" class="js-scrollTo">Présentation</a></li>
				<li><a href="#competence" class="js-scrollTo">Compétences</a></li>
				<li><a href="#realisations" class="js-scrollTo">Réalisations</a></li>
				<li><a href="#cv" class="js-scrollTo">CV</a></li>
				<li><a href="#contact" class="js-scrollTo">Contact</a></li>
			</ul>
		</nav>	
		<img src="media/img/devweb2.png" class="" id="logo" alt="logo">
	<header id="header">
		<div class="deskHidden">
			<button class="hamburger">&#9776;</button>
	  		<button class="cross">&#735;</button>
			<div class="menu">
			  <ul>
			    <li><a href="#header" class="js-scrollTo">Présentation</a></li>
				<a href="#photo" class="js-scrollTo"><li>Compétences</li></a>
				<a href="#photo1" class="js-scrollTo"><li>Réalisations</li></a>
				<a href="#realisations" class="js-scrollTo"><li>CV</li></a>
				<a href="#cv" class="js-scrollTo"><li>Contact</li></a>
			  </ul>
			</div> 
		</div>	
		<div id="title">
			<h1>Bruno Carbone</h1>
			<h2>Développeur Web</h2>
		</div>
	</header>
	<main>
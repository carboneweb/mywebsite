<footer>
		&copy; Bruno Carbone - 2016- Tous droits réservés
		<div>
			<a href="https://fr.linkedin.com/in/bruno-carbone-4a655911b"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
			<a href="http://fr.viadeo.com/fr/profile/bruno.carbone3"><i class="fa fa-viadeo-square" aria-hidden="true"></i></a>
			<a href="#header" class="js-scrollTo"><p>Haut de page</p><i class="fa fa-arrow-circle-up" aria-hidden="true"></i></a>
		</div>
	</footer>
	<script type="text/javascript" src="media/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="media/js/script.js">
		
	</script>
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-86040422-1', 'auto');
  ga('send', 'pageview');

</script>
  </body>
</html>
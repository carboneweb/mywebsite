 <div class="contenu">
			<section id="presentation" class="presentation">
				<h3>Présentation</h3>
				<div class="articlepres">
					<img src="media/img/photoprofil.jpg" alt="photoprofil">
				
				<article>Bonjour, je m'appelle Bruno Carbone. Dans mon ancienne vie je travaillais 
				comme contrôleur aérien dans la marine nationale.</br>

				A l'été 2016 j'ai décidé de me reconvertir dans un domaine tout aussi passionnant que 
				l'aéronautique et où les compétences que j'ai développé dans mon ancien métier me seront très utiles.</br>


				Eprouvant un fort attrait pour les nouvelles technologies et les défis tant techniques 
				qu'humains, le monde du web avec ses évolutions constantes et ses perspectives enthousiasmantes 
				semblait tout indiqué à ce que je le rejoigne.</br>


				Après avoir satisfait à une formation intensive et diplômante, je suis désormais à la recherche 
				de nouveaux challenges.</br>
 

				Rigueur, professionalisme, curiosité et bonne humeur sont les maîtres mots de ma vie professionnelle.
				J'espère que nous aurons autant de plaisir à travailler ensemble que j'en ai à apprendre et à élargir
				le champ de mes compétences.
				</article>
				</div>
			</section>
			<div class="photo" id="photo">
			</div>
<section class="competences" id="competence">
				<h3 id="competences">Compétences</h3>
					<div class="comp">	
						<article>
							<div class="progress">
							    <img src="media/img/logoHTML5.svg" alt="logoHTML5" width="80" height="80">
							    <progress value="90" max="100"></progress>
							    <strong>90%</strong>
							</div>
						</article>
						<article>
							<div class="progress">
							    <img src="media/img/logoPHP.svg" alt="logoPHP" width="80" height="80" class="logoBackground">
							    <progress value="50" max="100"></progress>
							    <strong>50%</strong>
							</div>
						</article>	
						<article>
							<div class="progress">
							    <img src="media/img/logoCSS3.svg" alt="logoCSS3" width="80" height="80">
							    <progress value="90" max="100"></progress>
							    <strong>90%</strong>
							</div>
						</article>			
						<article>
							<div class="progress">
							    <img src="media/img/logoMySQL.svg" alt="logoMySQL" width="80" height="80" class="logoBackground">
							    <progress value="50" max="100"></progress>
							    <strong>50%</strong>
							</div>
						</article>			
						<article>
							<div class="progress">
							    <img src="media/img/logoJS.png" alt="logoJS" width="65" height="80">
							    <progress value="60" max="100"></progress>
							    <strong>60%</strong>
							</div>
						</article>
						<article>
							<div class="progress">
							    <img src="media/img/jQuery.png" alt="jQuery" width="80" height="80" class="logoBackground">
							    <progress value="60" max="100"></progress>
							    <strong>60%</strong>
							</div>
						</article>
						<article>
							<div class="progress">
							    <img src="media/img/bootstrap.png" alt="bootstrap" width="65" height="80">
							    <progress value="70" max="100"></progress>
							    <strong>70%</strong>
							</div>
						</article>
						<article>
							<div class="progress">
							    <img src="media/img/ajax.png" alt="ajax" width="80" height="80" class="logoBackground">
							    <progress value="50" max="100"></progress>
							    <strong>50%</strong>
							</div>
						</article>
						<article>
							<div class="progress">
							    <img src="media/img/wordpress.png" alt="wordpress" width="80" height="80">
							    <progress value="70" max="100"></progress>
							    <strong>70%</strong>
							</div>
						</article>
					</div>
			</section>
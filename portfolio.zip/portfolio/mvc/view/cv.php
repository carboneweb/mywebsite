<section class="cv" id="cv">
				<h3>Télécharger mon CV</h3>
				<a href="media/CVdev.pdf"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>
			</section>
$(function(){
    ///////////////////////nav/////////////////////////////////////////
    $(document).ready(function() {
		$('.js-scrollTo').on('click', function() {
			var page = $(this).attr('href'); 
			var speed = 500; 
			$('html, body').animate( { scrollTop: $(page).offset().top }, speed );
		});
	});	


////////////////////burger menu////////////////////////////////////
    $(document).ready(function() {
		
		$( ".cross" ).hide();
		$( ".menu" ).hide();

		$( ".hamburger" ).click(function() {
		$( ".menu" ).slideToggle( "slow", function() {
		$( ".hamburger" ).hide();
		$( ".cross" ).show();
		});
		});

		$( ".cross" ).click(function() {
		$( ".menu" ).slideToggle( "slow", function() {
		$( ".cross" ).hide();
		$( ".hamburger" ).show();
		});
		});
	});			


/////////////////////////////////logo///////////////////////////////////////
		var animationName = 'bounceInDown';
	    
	    $(document).ready(function(){
	        $('#logo').addClass('animated '+ animationName );  
	    });

	    ///////////////////////media queries js//////////////////////////////////////////

    if (window.matchMedia("(min-width: 850px)").matches) {

	 	///////////parallax images de fond/////////////////////////

	 	var elementDocument = $(document);
	 		fondHeader		= $('header');
	 		photo			= $('div.photo');
	 		photo1			= $('div.photo1');

	 	elementDocument.on('scroll', function(){
	 	
	 		positionScroll  = elementDocument.scrollTop();
	 		photo.css('background-position', '0 ' + -positionScroll/7 + 'px');
	 		photo1.css('background-position', '0 ' + -positionScroll/3 + 'px');

	 	});	

	};
    
});
    
    

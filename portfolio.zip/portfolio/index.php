<?php
require_once("mvc/starter.php");
require_once("mvc/view/header.php");
require_once("mvc/view/presentation.php");
require_once("mvc/view/competences.php");
require_once("mvc/view/realisations.php");
require_once("mvc/view/cv.php");
require_once("mvc/view/contact.php");
require_once("mvc/view/footer.php");
?>


		
			
			
			
	

